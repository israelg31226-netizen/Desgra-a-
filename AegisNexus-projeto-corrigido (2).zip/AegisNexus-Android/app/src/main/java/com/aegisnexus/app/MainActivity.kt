package com.aegisnexus.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.sin

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var talkButton: Button
    private var readyToSpeak = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(3, 9, 24)
        window.navigationBarColor = android.graphics.Color.rgb(3, 9, 24)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 30, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(3, 9, 24))
        }
        val title = TextView(this).apply {
            text = "AEGIS NEXUS"
            textSize = 27f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(99, 226, 255))
        }
        val subtitle = TextView(this).apply {
            text = "ASSISTENTE PESSOAL • PROTÓTIPO"
            textSize = 11f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(134, 164, 195))
        }
        val orb = OrbView(this)
        status = TextView(this).apply {
            text = "Sistema inicializado. Toque para falar."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 18, 8, 18)
        }
        talkButton = Button(this).apply {
            text = "FALAR COM A AEGIS"
            isAllCaps = false
            textSize = 16f
            setOnClickListener { startListening() }
        }
        val footer = TextView(this).apply {
            text = "VERSÃO 0.1 • VOZ LOCAL DO ANDROID"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(100, 129, 159))
            setPadding(0, 22, 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(orb, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(talkButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale("pt", "BR"))
            readyToSpeak = languageResult != TextToSpeech.LANG_MISSING_DATA && languageResult != TextToSpeech.LANG_NOT_SUPPORTED
            if (readyToSpeak) tts?.setSpeechRate(0.96f)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Este aparelho não disponibilizou reconhecimento de voz."
            speak("O reconhecimento de voz não está disponível neste aparelho.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Estou ouvindo…"; talkButton.text = "OUVINDO…" }
                override fun onBeginningOfSpeech() { status.text = "Pode continuar falando." }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { talkButton.text = "FALAR COM A AEGIS"; status.text = "Processando sua fala…" }
                override fun onError(error: Int) { talkButton.text = "FALAR COM A AEGIS"; status.text = "Não consegui entender. Toque e tente novamente." }
                override fun onResults(results: Bundle?) {
                    talkButton.text = "FALAR COM A AEGIS"
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (words.isNullOrBlank()) { status.text = "Não recebi uma frase."; return }
                    status.text = "Você disse: $words"
                    speak("Entendido. Você disse: $words")
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a Aegis")
            }
            sr.startListening(intent)
        }
    }

    private fun speak(text: String) { if (readyToSpeak) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aegis_reply") }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else if (requestCode == 42) Toast.makeText(this, "Permita o microfone para conversar com a Aegis.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    private class OrbView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        private val cyan = android.graphics.Color.rgb(70, 225, 255)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            val radius = (width.coerceAtMost(height) * 0.29f).coerceAtLeast(60f)
            phase += 0.025f
            paint.shader = RadialGradient(cx, cy, radius * 1.55f, intArrayOf(0x5538dfff, 0x22228cff, 0x00000000), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius * 1.55f, paint)
            paint.shader = RadialGradient(cx - radius * .25f, cy - radius * .3f, radius * 1.3f, intArrayOf(0xffb5f7ff.toInt(), 0xff28bce9.toInt(), 0xff07508e.toInt(), 0xff03152e.toInt()), floatArrayOf(0f, .25f, .68f, 1f), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius * (1f + 0.018f * sin(phase.toDouble()).toFloat()), paint)
            paint.shader = null; paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = cyan
            canvas.drawCircle(cx, cy, radius * 1.18f, paint)
            paint.strokeWidth = 1f; paint.alpha = 150
            canvas.save(); canvas.rotate(phase * 35f, cx, cy); canvas.drawOval(cx-radius*1.42f, cy-radius*.38f, cx+radius*1.42f, cy+radius*.38f, paint); canvas.restore()
            paint.style = Paint.Style.FILL; paint.alpha = 255
            postInvalidateDelayed(40)
        }
    }
}
